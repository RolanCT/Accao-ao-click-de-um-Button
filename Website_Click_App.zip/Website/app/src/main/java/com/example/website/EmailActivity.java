package com.example.website;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class EmailActivity extends AppCompatActivity {
    private Button bt_send;
    private EditText from, to;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);


        bt_send=findViewById(R.id.id_enviar);
        from=findViewById(R.id.id_From);
        to=findViewById(R.id.id_TO);


        bt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto: "+from.getText().toString()));

                PackageManager manager = getPackageManager();
                List<ResolveInfo> infos = manager.queryIntentActivities(intent, 0);

                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"Destinatario@email.com :"+to.getText().toString()});

                intent.putExtra(Intent.EXTRA_SUBJECT, "Assunto do e-mail");
                intent.putExtra(Intent.EXTRA_TEXT, "Corpo do e-mail");


               /*if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);*/

                if (infos.size() > 0) {
                    // Há pelo menos um aplicativo que pode lidar com a ação de enviar e-mail
                    startActivity(intent);
                }
                 else {
                    Toast.makeText(getApplicationContext(), "Não há aplicativos que possam enviar e-mails", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}