package com.example.website;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.website.databinding.ActivityMainBinding;

public class SegundaTela extends AppCompatActivity {

   // private ActivityMainBinding mainBinding;
    /*static  final String USERNAMECONSTANTE="i31";
    static  final String PASSWORDCONSTANTE = "A123R";*/
    private   Button bt_website,bt_email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /// mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_segunda_tela);

        bt_website= findViewById(R.id.bt_website);
        bt_email=findViewById(R.id.bt_email);

        bt_website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(SegundaTela.this,MainActivity.class);
                Toast.makeText(SegundaTela.this, "WEBSITE", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

        bt_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent =new Intent(SegundaTela.this,EmailActivity.class);
                Toast.makeText(SegundaTela.this, "EMAIL", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });














    }
}